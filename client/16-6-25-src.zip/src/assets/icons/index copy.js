export { ReactComponent as ClosedCaption } from './closed_caption.svg';
export { ReactComponent as ClosedCaptionDisabled } from './closed_caption_disabled.svg';
export { ReactComponent as Pause } from './pause.svg';
export { ReactComponent as Play } from './play_arrow.svg';
export { ReactComponent as VolumeOff } from './volume_off.svg';
export { ReactComponent as VolumeUp } from './volume_up.svg';
