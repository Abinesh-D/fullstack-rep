let appMode = "1"

module.exports = appMode


