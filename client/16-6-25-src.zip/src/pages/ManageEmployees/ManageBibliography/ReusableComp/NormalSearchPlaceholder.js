const NormalSearchPlaceholder = () => (
    <div className="text-center py-5">
      <h5>Normal Patent Search Section</h5>
      <p>Coming soon...</p>
    </div>
  );
  
  export default NormalSearchPlaceholder;
  