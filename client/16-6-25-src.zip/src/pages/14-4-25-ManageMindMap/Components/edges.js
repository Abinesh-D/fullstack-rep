export const initialEdges = [{ id: '1-2', source: '1', target: '2' }];



// export const initialEdges = [];
